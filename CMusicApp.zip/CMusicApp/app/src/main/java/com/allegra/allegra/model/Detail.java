package com.allegra.allegra.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class Detail {

    @PrimaryKey(autoGenerate = true)
    private int idDetail;

    @ColumnInfo(name = "lyrics")
    private String lyrics;


    public Detail() {}

    public int getIdDetail() { return idDetail; }

    public void setIdDetail(int idDetail) { this.idDetail = idDetail; }

    public String getLyrics() { return lyrics; }

    public void setLyrics(String lyrics) { this.lyrics = lyrics; }


    @Ignore
    public Detail(int idDetail, String lyrics){
        this.idDetail = idDetail;
        this.lyrics = lyrics;
    }

}
